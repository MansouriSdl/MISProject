﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MIS.Domain.Constants
{
    public static class OrderStatus
    {
        public const string ORDERED = "A venir";
        public const string IN_STOCK = "En stock";
    }
}
