﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MIS.Domain.Constants
{
    public static class AlertType
    {
        public const string DATE = "Date";
        public const string QUANTITY = "Quantity";

    }
}
