﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MIS.Domain.Constants
{
    public class EquipmentsState
    {
        public const string EXCELLENT = "Excellent";
        public const string GOOD = "Bien";
        public const string DAMAGED = "Endommagé";
    }
}
