﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MIS.Application.Models.Responses
{
     public  class OrderStatusReportModel
    {
        public string Status { get; set; }
        public decimal Value { get; set; }

    }
}
