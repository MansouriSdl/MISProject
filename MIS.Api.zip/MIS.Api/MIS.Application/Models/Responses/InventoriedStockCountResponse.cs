﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MIS.Application.Models.Responses
{
    public class InventoriedStockCountResponse
    {
        public string Designation { get; set; }
        public int Count { get; set; }
    }
}
